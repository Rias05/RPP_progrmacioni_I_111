disuclpe profe solo descomprimi mi carpeta en que tenia todo el codigo
creo que ahi pude
